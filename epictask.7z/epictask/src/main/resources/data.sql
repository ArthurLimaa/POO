-- src/main/resources/data.sql

INSERT INTO TASK (ID, TITTLE, DESCRIPTION, SCORE, STATUS)
VALUES (1, 'Figma', 'criando o prototipo', '10', '0');

INSERT INTO TASK  (ID, TITTLE, DESCRIPTION, SCORE, STATUS)
VALUES(2, 'Java', 'estudando', '20', '0');

